//
//  CollectionViewCell.swift
//  TEST
//
//  Created by Vuha Sri on 12/24/18.
//  Copyright © 2018 Vuha Sri. All rights reserved.
//

import UIKit

class NewCollectionViewCell: UICollectionViewCell {
    
        @IBOutlet var lblname: UILabel!
        
        @IBOutlet var lblcapital: UILabel!
        
        
        
        override func awakeFromNib() {
            super.awakeFromNib()
            // Initialization code
        }
    

    
}
